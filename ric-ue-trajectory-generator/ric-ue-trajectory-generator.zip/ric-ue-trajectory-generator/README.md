# ric-ue-trajectory-generator

## Packages

1. Python>=3.8
2. pip>=3.8

## Pip install

`pip install -r requirements.txt`

## Run UE trajectory generator

`python traj_gen.py --map_width 2000 --map_length 2000 --num_ue 2 --ue_speed 3 --way_points 10 --show_plot`

1. --map_width: the width(vertical) of map in meters
2. --map_length: the length(horizontal) of map in meters
3. --num_ue: number of UE
4. --ue_speed: moving speed in m/s
5. --way_points: number of random way points
6. --show_plot: show UE's trajectory in plot, remove this to disable plot

## Get output

The coordinates of UE's trajectory are output in the csv files under `./output/` folder. The file name is formated by UE ID and a datetime, such as `UE0_05-08-2021_11-42-40.csv`, where UE0 represents the UE with ID 0 and 05-08-2021_11-42-40 is datetime of creating this file. In the csv file, there are 4 columns, x(m), y(m), instant speed(m/s) and timestamp(s).
