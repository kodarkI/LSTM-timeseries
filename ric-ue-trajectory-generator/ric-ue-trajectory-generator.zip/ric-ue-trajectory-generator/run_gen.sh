#!/bin/bash

python traj_gen.py --map_width 2000 --map_length 2000 --num_ue 2 --ue_speed 3 --way_points 10 --show_plot