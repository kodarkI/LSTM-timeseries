import random
import argparse

from numpy import double
from traj_map import TrajMap

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-w', '--map_width')
    parser.add_argument('-l', '--map_length')
    parser.add_argument('-u', '--num_ue')
    parser.add_argument('-s', '--ue_speed')
    parser.add_argument('-p', '--way_points')
    parser.add_argument('-d', '--show_plot', nargs='?', const=True,default=False)
    args = parser.parse_args()
    
    map_width=float(args.map_width)
    map_length=float(args.map_length)
    num_ue=int(args.num_ue)
    ue_speed=float(args.ue_speed)
    way_points=int(args.way_points)
    show_plot=bool(args.show_plot)

    tmap=TrajMap(map_width, map_length, num_ue, ue_speed, way_points)
    for i in range(num_ue):
        tmap.output_traj(i, "./output")

    if show_plot:
        tmap.plot_all_traj()
    

if __name__ == '__main__':
    main()