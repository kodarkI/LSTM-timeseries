import numpy as np
import random
import csv
import os
from datetime import datetime

from cubic_spline_planner import Spline2D

class UECoord:
    def __init__(self):
        self.x = 0
        self.y = 0

class MapEntity:
    def __init__(self,map_width:float, map_length:float, border_width:float):
        self.min_x = -map_width/2.0
        self.max_x = map_width/2.0
        self.min_y = -map_length/2.0
        self.max_y = map_length/2.0
        self.border_width = border_width

    def is_inside_border(self, p: UECoord):
        return p.x >= self.border_min_x and p.x <= self.border_max_x and p.y >= self.border_min_y and p.y <= self.border_max_y

    @property
    def border_min_x(self):
        return self.min_x + self.border_width
    @property
    def border_max_x(self):
        return self.max_x + self.border_width
    @property
    def border_min_y(self):
        return self.min_y + self.border_width
    @property
    def border_max_y(self):
        return self.max_y + self.border_width
    


class UEEntity:
    def __init__(self, id, speed, num_way_points, map:MapEntity):
        self.id = id
        self.speed = speed
        self.num_way_points = num_way_points
        self.map = map

        self.waypoint_x = []
        self.waypoint_y = []

        self.trace_range = None
        self.trace_x = []
        self.trace_y = []
        self.insta_speed = []
    
    def __min2edge(self, point:UECoord):
        dis2min_x=point.x - self.map.min_x
        dis2max_x=self.map.max_x - point.x
        min2edge_x=min(dis2min_x, dis2max_x)
        dis2min_y=point.y - self.map.min_y
        dis2max_y=self.map.max_y - point.y
        min2edge_y=min(dis2min_y, dis2max_y)
        return min2edge_x, min2edge_y

    def __min2border(self, point:UECoord):
        dis2min_x=point.x - self.map.border_min_x
        dis2max_x=self.map.border_max_x - point.x
        min2border_x=min(dis2min_x, dis2max_x)
        dis2min_y=point.y - self.map.border_min_y
        dis2max_y=self.map.border_max_y - point.y
        min2border_y=min(dis2min_y, dis2max_y)
        return min2border_x, min2border_y

    def __max2border(self, point:UECoord):
        dis2min_x=point.x - self.map.border_min_x
        dis2max_x=self.map.border_max_x - point.x
        max2border_x=max(dis2min_x, dis2max_x)
        dis2min_y=point.y - self.map.border_min_y
        dis2max_y=self.map.border_max_y - point.y
        max2border_y=max(dis2min_y, dis2max_y)
        return max2border_x, max2border_y

    def __random_way_points(self):
        start_pt = UECoord()
        start_pt.x = random.randrange(self.map.border_min_x,self.map.border_max_x)
        start_pt.y = random.randrange(self.map.border_min_y,self.map.border_max_y)
        way_points=[]
        way_points.append(start_pt)
        for i in range(1, self.num_way_points):
            to_border_x, to_2border_y=self.__max2border(way_points[i-1])
            # next way point
            way_pt = UECoord()
            while True:
                way_pt.x = way_points[i-1].x + random.randrange(-to_border_x, to_border_x)    
                way_pt.y = way_points[i-1].y + random.randrange(-to_2border_y, to_2border_y)
                if self.map.is_inside_border(way_pt):
                    break
            way_points.append(way_pt)
        return way_points
    
    def __euclidean_dist(self, px, py, qx, qy):
        return np.sqrt(np.power((qx-px),2)+np.power((qy-py),2))

    def gen_traj(self):
        way_points=self.__random_way_points()
        for pt in way_points:
            self.waypoint_x.append(pt.x)
            self.waypoint_y.append(pt.y)

        sp = Spline2D(self.waypoint_x, self.waypoint_y)
        s = np.arange(0, sp.s[-1], self.speed)
        self.trace_range = range(0,len(s))
        prev_x=0
        prev_y=0
        for i_s in s:
            ix, iy = sp.calc_position(i_s)
            self.trace_x.append(ix)
            self.trace_y.append(iy)
            if i_s == 0:
                self.insta_speed.append(0)
            else:
                self.insta_speed.append(self.__euclidean_dist(prev_x, prev_y, ix, iy))
            prev_x = ix
            prev_y = iy
        pass 

class TrajMap:
    def __init__(self, map_width:float, map_length:float, num_ue:int, ue_speed:float, num_way_points:int):
        self.map_wdith=map_width
        self.map_length=map_length
        self.num_ue=num_ue
        self.ue_speed=ue_speed
        self.num_way_points=num_way_points

        self.map = MapEntity(self.map_wdith, self.map_length, 5)
        self.UEs = []
        for i in range(0, self.num_ue):
            ue=UEEntity(i, self.ue_speed, self.num_way_points, self.map)
            ue.gen_traj()
            self.UEs.append(ue)
        pass

    def plot_traj(self, ue_id):
        import matplotlib.pyplot as plt
        ue=self.UEs[ue_id]
        plt.subplots(1)
        plt.plot(ue.waypoint_x, ue.waypoint_y, "xb", label="input")
        plt.plot(ue.trace_x, ue.trace_y, "-r", label="spline")
        plt.grid(True)
        plt.axis("equal")
        plt.xlabel("x[m]")
        plt.ylabel("y[m]")
        plt.legend()
        plt.show()

    def plot_all_traj(self):
        import matplotlib.pyplot as plt
        for idx, ue in enumerate(self.UEs):
            plt.subplots(1)
            plt.plot(ue.waypoint_x, ue.waypoint_y, "xb", label="input")
            plt.plot(ue.trace_x, ue.trace_y, "-r", label="spline")
            plt.grid(True)
            plt.axis("equal")
            plt.xlabel("x[m]")
            plt.ylabel("y[m]")
            plt.legend()
        plt.show()

    def output_traj(self, ue_id, csv_folder):
        ue=self.UEs[ue_id]

        data=[]
        for i_s in ue.trace_range:
            data.append([ue.trace_x[i_s], ue.trace_y[i_s], ue.insta_speed[i_s], i_s])

        if not os.path.exists(csv_folder):
            os.mkdir(csv_folder)
        now=datetime.now()
        dt_str = now.strftime("%d-%m-%Y_%H-%M-%S")
        csv_file = "UE%d_%s.csv"%(ue_id,dt_str)
        csv_fullpath = os.path.join(csv_folder, csv_file)
        with open(csv_fullpath, 'w',newline='') as f:
            wtr=csv.writer(f)
            
            wtr.writerows(data)
        
        